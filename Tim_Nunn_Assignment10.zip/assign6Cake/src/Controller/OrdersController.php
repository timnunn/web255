<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Orders Controller
 * 
 * @property \App\Model\Table\Orderstable $Orders
 * 
 * @method \App\Model\Entity\Order[]\Cake\Datasource\results
 * 
 */
class OrdersController extends AppController
{

    /**
     * Index method
     * 
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $orders = $this->paginate($this->Orders);

        $this->set(compact('orders'));
    }

    /** View method
     * 
     * @param string|null $id Order id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException
     */
    public function view($id = null)
    {
        $order = $this->Orders->get($id, ['contain' => []]);
    }
}