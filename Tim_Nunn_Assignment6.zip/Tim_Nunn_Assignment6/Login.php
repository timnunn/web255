<?PHP
session_start();
if (!empty($_SESSION['PASSWD'])){
   header("Location: OrderRpt.php");
}

$Form1 =<<<ENDFORM
<H1> <center>Store Login </center></H1> 
<FORM Method="Post">
<center>
UserName:
<INPUT TYPE='TEXT' NAME='User' SIZE=8> <BR>
PassWord:
<INPUT TYPE='PASSWORD' NAME='Passwd' SIZE=8> <BR>
<INPUT TYPE='SUBMIT' NAME='submit' value='Login'> <BR>
</center>
</FORM>
ENDFORM;

if (isset($_REQUEST['submit'])) {
   include("storeConnect.php");
   $query = "Select count(*) as cnt from Users Where ID='"
		.$_REQUEST["User"]."' And Passwd = '".$_REQUEST["Passwd"]."';";
   $result = $conn->query($query);
   if ($result->num_rows > 0) {
       session_start();
       $_SESSION['ID']=$_REQUEST['User'];
       $_SESSION['PASSWD']=$_REQUEST['Passwd'];
     header("Location: OrderRpt.php");
   }
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>PHP HereString </title>
</head>
<body style="background-color:33F9FF">
<H1> <center> Order Entry </center></H1> 

<?PHP echo $Form1; ?>
</body>
</html>
