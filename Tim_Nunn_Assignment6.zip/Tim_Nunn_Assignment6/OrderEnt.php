<?PHP
if (isset($_REQUEST['Return'])) {
   header("Location: index.html");	   
}

$Form1 =<<<ENDFORM
<FORM Method="Post">
<table><tr><td>
First Name: <td><INPUT TYPE='TEXT' NAME='FName' SIZE=25><td> Last Name:<td> 
<INPUT TYPE='TEXT' NAME='LName' SIZE=35>
<tr><td>
Account:<td><INPUT TYPE='TEXT' NAME='Account' SIZE=10>
<tr><td>
Credit Card No: <td><INPUT TYPE='TEXT' NAME='CCN' SIZE=16> 
<td>Exp Date: <td><INPUT TYPE='TEXT' NAME='ExpDate' SIZE=10>
<tr><td>Item: <td><INPUT TYPE='TEXT' NAME='Item' SIZE=25>
<td>Quantity: <td><INPUT TYPE='TEXT' NAME='Qty' SIZE=11> 
</table><br><br> <center>
<INPUT TYPE='SUBMIT' NAME='submit' value='Submit Order'>
<INPUT TYPE='SUBMIT' NAME='Return' VALUE='Main Menu'>
</center></FORM>
ENDFORM;

if (isset($_REQUEST['submit'])) {
   include("storeConnect.php");
   $query = "insert into Orders (Fname,Lname,Account,CCN,ExpDate,Item,Qty) values ('"
		.$_REQUEST["FName"]
		."', '"
		.$_REQUEST["LName"]
		."', '"
		.$_REQUEST["Account"]
		."', '"
		.$_REQUEST["CCN"]
		."', '"
		.$_REQUEST["ExpDate"]
		."', '"
		.$_REQUEST["Item"]
		."', '"
		.$_REQUEST["Qty"]
		."') ";
  mysqli_query($conn, $query);
  $conn->close();
$Form1 =<<<RETFORM
<H1> <center> Creating entry </br>
<center> Order Processed - Thanks
<br/>
<br/>
<form method="post">
<INPUT TYPE='SUBMIT' NAME='Return' VALUE='Main Menu'>
</form>
</center>
RETFORM;
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>PHP HereString </title>
</head>
<body style="background-color:33F9FF">
<H1> <center> Order Entry </center></H1> 

<?PHP echo $Form1; ?>

</body>
</html>
