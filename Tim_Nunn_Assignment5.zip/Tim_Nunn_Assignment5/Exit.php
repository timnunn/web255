<?php
session_start();
if (isset($_SESSION['ID'])) {
   unset($_SESSION['ID']);
   unset($_SESSION['PASSWD']);
   session_destroy();
  header("Location: http://localhost:8081");
} else {
  header("Location: http://localhost:8081/dashboard");
}
?>
