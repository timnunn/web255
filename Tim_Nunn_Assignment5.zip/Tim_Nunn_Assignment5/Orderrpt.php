<?php
if (isset($_REQUEST['MainMenu'])) {
   header("Location: index.html");	   
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Order Report</title>

</head>
<body bgcolor="33F9FF">
<h2>Date: <? echo date("m", time()),"/".date("d",time())."/".date("y",time()); ?> </h2>
<h1><center>Assignment5</center></h1>
<h1><center>Order Report</center></h1>
<?php
if (isset($_REQUEST['MainMenu'])) {
   header("Location: index.html");	   
}
include('assign5Connect.php'); 
$query = "select * from Orders";
$result = $conn->query($query);
 if ($result->num_rows > 0) {
   while ($row = $result->fetch_assoc()) {
      echo '<b>Name: </b>'.$row['FName']." ".$row['LName'];
      echo "<br>";
      echo '<b>Account: </b>'.$row['Account'];
      echo "<br>";
      echo '<b>CCN: </b>'.$row['CCN']."<b>   Expiration Date: </b>".$row['ExpDate'];
      echo "<br>";
      echo '<b>Item: </b>'.$row['Item']."<b>   Qantity: </b>".$row['Qty'];
      echo "<br> <hr> <br>";
   }
}
$conn->close();

echo <<<RETFORM
<center>
<form method="post">
<INPUT TYPE='SUBMIT' NAME='MainMenu' VALUE='Main Menu'>
</form>
</center>
RETFORM;

?>
</body>
</html>
