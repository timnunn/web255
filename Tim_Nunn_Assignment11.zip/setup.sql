drop database if exists companies;
create database companies;
use companies;
drop table if exists Orders;
create table Orders(
    id          bigint(20) NOT NULL AUTO_INCREMENT,
    name	varchar(255),
    email	varchar(255),
    address 	varchar(255),
    created_at  timestamp,
    updated_at  timestamp,
    PRIMARY KEY (id));
grant delete, insert, select, update on Orders to joeuser@localhost identified by 'resueoj';
drop table if exists Users;
create table Users(
    id		bigint(20) NOT NULL AUTO_INCREMENT,
    name	varchar(255),
    email	varchar(255),
    email_verified_at timestamp,
    password	varchar(255),
    remember_token  varchar(100),
    created_at	timestamp,
    updated_at  timestamp,
    PRIMARY KEY (id));
grant delete, insert, select, update on Users to joeuser@localhost identified by 'resueoj';
FLUSH PRIVILEGES;
insert into Users (Fname,Lname,ID,PassWD) values('Tim','Nunn','navy1','navy1');
insert into Users (Fname,Lname,ID,PassWD) values('Admin','Admin','admin','admin');
COMMIT;
