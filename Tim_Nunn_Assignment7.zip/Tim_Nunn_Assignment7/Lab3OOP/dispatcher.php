<?PHP  //The purpose of this file to to get us to the right controller.
//this imports the Order_Controller to use
use Orderent\Controllers\Order_Controller;
//this import the User_Controller to use
use Orderent\Controllers\User_Controller;

//echo "In Dispatcher  </br> </br>";
//var_dump($_REQUEST);
//looking at the request array which has the information coming from index.html
if ((isset($_REQUEST['Orderent'])) or 
    (isset($_REQUEST['submit'])))  {
    require_once __DIR__ . '/Orderent/Controllers/Order_Controller.php';
		//instantiate the order controller.
    $order = new Order_Controller();
		//calls the router requests
    $order->Route_Request();
}
if (isset($_REQUEST['Orderrpt']))  {
    require_once __DIR__ . '/Orderent/Controllers/Order_Controller.php';
		//instantiate the Order Controller.
    $order = new Order_Controller();
		//calls the router requests	
    $order->Route_Request();
}
if ((isset($_REQUEST['Userent'])) or 
    (isset($_REQUEST['submitUser'])))  {
   require_once __DIR__ . '/Orderent/Controllers/User_Controller.php';
	 //instantiate the User Controller
    $user = new User_Controller();
		//calls the router requests	
    $user->Route_Request();
}
if (isset($_REQUEST['Userrpt']))  {
    require_once __DIR__ . '/Orderent/Controllers/User_Controller.php';
		//instantiate the User Controller
    $user = new User_Controller();
		//calls the router requests	
    $user->Route_Request();
}
//Returns to the index.html
if (isset($_REQUEST['Return'])) {
  header("Location: index.html");	   
}
//Calls the Exit.php file
if (isset($_REQUEST['Btn_Exit'])) {
  header("Location: Exit.php");	   
}
?>