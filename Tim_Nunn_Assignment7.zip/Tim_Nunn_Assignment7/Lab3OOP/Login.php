<?PHP
session_start();
if (!empty($_SESSION['PASSWD'])){
   header("Location: OrderRpt.php");
}
//displays the logon form with User Name and Password fields to be entered
$Form1 =<<<ENDFORM
<H1> <center>Lab3 Login </center></H1> 
<FORM Method="Post">
<center>
UserName:
<INPUT TYPE='TEXT' NAME='User' SIZE=8> <BR>
PassWord:
<INPUT TYPE='PASSWORD' NAME='Passwd' SIZE=8> <BR>
<INPUT TYPE='SUBMIT' NAME='submit' value='Login'> <BR>
</center>
</FORM>
ENDFORM;
//The below code will submit request and connect to the mysql database for verification and either grant access or deny access
if (isset($_REQUEST['submit'])) {
   include("Includes\Lab3Connect.php");
   $query = "Select count(*) as cnt from Users Where ID='"
		.$_REQUEST["User"]."' And Passwd = '".$_REQUEST["Passwd"]."';";
   $result = mysql_query($query) or die("query failed: $query ".mysql_error());
   $row = mysql_fetch_array($result);
   if ($row['cnt']>0) {
  //   session_register('ID','PASSWD');
     $_SESSION['ID']=$_REQUEST['User'];
     $_SESSION['PASSWD']=$_REQUEST['Passwd'];
     header("Location: OrderRpt.php");
   }
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>PHP HereString </title>
</head>
<body>
<H1> <center> Order Entry </center></H1> 

<?PHP echo $Form1; ?>
</body>
</html>
