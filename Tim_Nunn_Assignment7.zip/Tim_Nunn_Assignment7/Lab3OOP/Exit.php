<?php  //The purpose of this file to end session and send to predefined location.
session_start();
if (isset($_SESSION['ID'])) {
   unset($_SESSION['ID']);
   unset($_SESSION['PASSWD']);
   session_unregister('ID'.'PASSWD');
   session_destroy();
   header("Location: HTTP://localhost/");
} else {
  header("Location: HTTP://www.hacc.edu/");
}
?>
