<?PHP  //The Order Controller is basically the traffic cop which routes requests and coordinates activity between views and models or HTML screen
namespace Orderent\Controllers;
//Below are the other files that are being brought in for the controller to use.
use Orderent\Views\Order_View;
use Orderent\Views\Order_Summary_Report;
use Orderent\Models\Order_Table;
//The require_once is identical to require except that PHP will check if the file is already included, if so it won't include it again.
require_once 'Orderent\Views\Order_View.php';
require_once 'Orderent\Views\Order_Summary_Report.php';
require_once 'Orderent\Models\Order_Table.php';

class Order_Controller {

// Accessor Methods for rmember variables

public function Route_Request() {
  //Checks to see if the Request value is set to Return, if so it returns back to the index.html
  if (isset($_REQUEST['Return'])) {
    header("Location: index.html");	   
  } else if (isset($_REQUEST['submit'])) {
    //Checks to see if the Request value is Submit Order, if so it will insert the requested data to the database 
    if ($_REQUEST['submit']=="Submit Order") {
       $this->Insert_Request_Data();
     } 
   } else if (isset($_REQUEST['Orderent'])) {
    //This will display the Order Entry Form
     $this->Display_Order_Form();
  } else if (isset($_REQUEST['Orderrpt']))  {
    //This will display the Order Report
     $this->Display_Order_Report(); 
  } else {

  }
}
//The below methods are also referred to as Static Functions.  
// Utility Methods

//This returns the type of an object.
public function GetType(){
  return "OrderController";
}
//This function would validate business rules for the controller
public function Validate_Bunsiness_Rules() {
   $Date_valid = true;
   return $Data_VAlid;  
}

public function Display_Order_form(){
  //Created a new Order_View class which calls the display order
  {
  $View = new Order_View();
  $View->Display_Order_Form();
}

public function Display_Order_Report() {
  //Created a new Order_Summary_Report class which calls the Summary Report  
  $View = new Order_Summary_Report();
  //Instantate the Order Table and then call the viewer.
  $ordTable = new Order_Table();
  $View->Display_Summary_Report($ordTable->Get_Order_Data());
}

public function Insert_Request_Data(){
  //Created new Order_Table class and Order_View class  
  $ordTable = new Order_Table();
  $View = new Order_View();
  if ($ordTable->Validate_Order_Data()) {
    $ordTable->Insert_Request_Data();
    $View->Display__Message("<h1>Data Processed</h1>");
  } else {
    $View->Display__Message("<h1>Data Error Please Retry</h1>");
  }
}
}// end Order class
?>