<?PHP
namespace Orderent\Controllers;
//Below are the other files that are being brought in for the controller to use.
use Orderent\Views\User_View;
use Orderent\Views\User_Summary_Report;
use Orderent\Models\User_Table;
//The require_once is identical to require except that PHP will check if the file is already included, if so it won't include it again.
require_once 'Orderent\Views\User_View.php';
require_once 'Orderent\Views\User_Summary_Report.php';
require_once 'Orderent\Models\User_Table.php';

class User_Controller {

// Accessor Methods for rmember variables
  //Checks to see if the Request value is set to Return, if so it returns back to the index.html
public function Route_Request() {
  if (isset($_REQUEST['Return'])) {
    header("Location: index.html");
    //Checks to see if the Request value is Submit User, if so it will insert the requested data to the database
  } else if (isset($_REQUEST['submitUser'])) {
    if ($_REQUEST['submitUser']=="submitUser") {
       $this->Insert_Request_Data();
     }
     //This will display the User Form
   } else if (isset($_REQUEST['Userent'])) {
     $this->Display_User_Form();
    //This will display the Order Report    
  } else if (isset($_REQUEST['Userrpt']))  {
     $this->Display_User_Report(); 
  } else {

  }
}

// Utility Methods
public function GetType(){
  return "UserController";
}

public function Validate_Bunsiness_Rules() {
   $Date_valid = true;
   return $Data_VAlid;  
}

public function Display_User_Form(){
  $View = new User_View();
  $View->Display_Entry_Form();
}

public function Display_User_Report(){
  $View = new User_Summary_Report();
  $userTable = new User_Table();
  $View->Display_Summary_Report($userTable->Get_User_Data());
}

public function Insert_Request_Data(){
  $userTable = new User_Table();
  $View = new user_View();
  if ($userTable->Validate_User_Data()) {
    $userTable->Insert_Request_Data();
    $View->Display__Message("<h1>Data Processed</h1>");
  } else {
    $View->Display__Message("<h1>Data Error Please Retry</h1>");
  }
}
}// end user Controller class
?>