<?PHP
namespace Orderent\Views;
//Defines the User View class.
class User_View {
//This function defines what is to be displayed, HTML Header, Message, HTML Footer.
   public function Display__Message($mess) {
      $this->Display_HTML_Header();
      echo <<<RETFORM
        <center> $mess
        <form method="post">
        <INPUT TYPE='SUBMIT' NAME='Return' VALUE='Main Menu'>
         </form>
         </center>
RETFORM;
       $this->Display_HTML_Footer();
   } 
//This function defines the order to be displayed.
   public function Display_user_Form() {
       $this->Display_HTML_Header();
       $this->Display_Entry_form();
       $this->Display_HTML_Footer();
    } 
//This function defines the HTML Header to be displayed
   public function Display_HTML_Header() {
     $header =<<<ENDFORM
     <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
     <html>
     <head>
     <title>User Input Form</title>
     </head>
     <body>
ENDFORM;
  echo $header;
}
//This function defines the HTML Footer and what is to be displayed.
public function Display_HTML_Footer() {
  $Footer =<<<ENDFORM
    </body>
     </html>
ENDFORM;
  echo $Footer;
}
//This function defines the Entry Form and what is to be displayed.
public function Display_Entry_Form() {
  $form1=<<<ENDFORM
      <center><h1>user Entry Form</h1>
      </br>
      </br> 
      <FORM Method="Post" action="dispatcher.php">
      <table><tr><td>
      First: <td><INPUT TYPE='TEXT' NAME='FName' SIZE=25><td> Last:<td> 
      <INPUT TYPE='TEXT' NAME='LName' SIZE=35>
      <tr><td>
      Identificatoin:<td><INPUT TYPE='TEXT' NAME='ID' SIZE=14>
      <tr><td>
      Pass Word: <td><INPUT TYPE='TEXT' NAME='PassWD' SIZE=16> 
      </table><br><br> 
      <INPUT TYPE='SUBMIT' NAME='submitUser' value='submitUser'>
      <INPUT TYPE='SUBMIT' NAME='Return' VALUE='Main Menu'>
      </center>
      </FORM>
ENDFORM;
      echo $form1;
   }
}// end user View Class 

?>