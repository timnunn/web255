<?PHP
namespace Orderent\Views;
//Defines the class User Summary Report
class User_Summary_Report {
//THis function defines the order to be displayed for view, to display the HTML Header, Message, and HTML Footer.
   public function Display__Message($mess) {
      $this->Display_HTML_Header();
      echo <<<RETFORM
        <center> $mess
        <form method="post">
        <INPUT TYPE='SUBMIT' NAME='Return' VALUE='Main Menu'>
         </form>
         </center>
RETFORM;
       $this->Display_HTML_Footer();
   } 
//Defines the User Report on what is to be displayed and in what order.
   public function Display_User_Report() {
       $this->Display_HTML_Header();
       $this->Display_Entry_form();
       $this->Display_HTML_Footer();
    } 
//This function defines the HTML Header information.
   public function Display_HTML_Header() {
     $header =<<<ENDFORM
     <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
     <html>
     <head>
     <title>PHP HereString </title>
     </head>
     <body>
ENDFORM;
  echo $header;
}
//This function defines the HTML Footer information to be displayed.
public function Display_HTML_Footer() {
  $Footer =<<<ENDFORM
    </body>
     </html>
ENDFORM;
  echo $Footer;
}
//This function defines the Report Header information to be displayed.
public function Display_Report_Header() {
  $rptDate = date("m", time())."/".date("d",time())."/".date("y",time()); 
 echo <<<ENDREORTHEAD
  <body bgcolor="DDFFEE">
  <h2>Date: $rptDate </h2>
  <h1><center>WEB 255 Lab 3 OOP Order Entry Users</center></h1>
   <h1><center>User Report</center></h1>
ENDREORTHEAD;
}
//This function defines the Summary Report and what is to be displayed.
public function Display_Summary_Report($rows) {
  $this-> Display_HTML_Header();  
  $this->Display_Report_Header();
  $pos = 0;
  foreach($rows as $key => $value){
    echo '<b>Name: </b>'.$rows[$pos]['Fname']." ".$rows[$pos]['Lname'];
    echo "<br>";
    echo '<b>Identification: </b>'.$rows[$pos]['ID'];
    echo "<br>";
    echo '<b>Password: </b>'.$rows[$pos]['PassWD'];
    echo "<br>";
    echo "<br> <hr> <br>";
    $pos++;
 } 
   echo <<<RETFORM
      <center>
      <form method="post" action="dispatcher.php">
      <INPUT TYPE='SUBMIT' NAME='Return' VALUE='Main Menu'>
      </form>
      </center>
RETFORM;
    $this-> Display_HTML_Footer(); 
}
}// end user View Class 

?>