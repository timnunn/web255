<?PHP
namespace Orderent\Views;
//Defining the Class Order_View
class Order_View {

   public function Display__Message($mess) {
    //the use of $this with redirection arrow -> it will display the header information first.
      $this->Display_HTML_Header();
      //this will display a message and return to the menu.
      echo <<<RETFORM
        <center> $mess
        <form method="post">
        <INPUT TYPE='SUBMIT' NAME='Return' VALUE='Main Menu'>
         </form>
         </center>
RETFORM;
       $this->Display_HTML_Footer();
   } 
//This is a driver function which will display an empty form.
   public function Display_Order_Form() {
       $this->Display_HTML_Header();
       $this->Display_Entry_form();
       $this->Display_HTML_Footer();
    } 
//This will put out the header section of the HTML document
   public function Display_HTML_Header() {
     $header =<<<ENDFORM
     <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
     <html>
     <head>
     <title>PHP HereString </title>
     </head>
     <body>
ENDFORM;
  echo $header;
}
//This will put out the closing tag of the HTML document.
public function Display_HTML_Footer() {
  $Footer =<<<ENDFORM
    </body>
     </html>
ENDFORM;
  echo $Footer;
}
//This defines and displays the Display Entry Form
public function Display_Entry_Form() {
  $form1=<<<ENDFORM
      <center><h1>Order Entry Form</h1>
      </br>
      </br> 
      <FORM Method="Post" action="dispatcher.php">
      <table><tr><td>
      First: <td><INPUT TYPE='TEXT' NAME='FName' SIZE=25><td> Last:<td> 
      <INPUT TYPE='TEXT' NAME='LName' SIZE=35>
      <tr><td>
      Account:<td><INPUT TYPE='TEXT' NAME='Account' SIZE=14>
      <tr><td>
      Credit Card No: <td><INPUT TYPE='TEXT' NAME='CCN' SIZE=16> 
      <td>Exp Date: <td><INPUT TYPE='TEXT' NAME='ExpDate' SIZE=10>
      <tr><td>Item: <td><INPUT TYPE='TEXT' NAME='Item' SIZE=14>
      <td>Quantity: <td><INPUT TYPE='TEXT' NAME='Qty' SIZE=14> 
      </table><br><br> 
      <INPUT TYPE='SUBMIT' NAME='submit' value='Submit Order'>
      <INPUT TYPE='SUBMIT' NAME='Return' VALUE='Main Menu'>
      </center>
      </FORM>
ENDFORM;
      echo $form1;
   }
}// end Order View Class 

?>