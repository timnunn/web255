<?PHP
namespace Orderent\Views;
//Defining the Class Order_Summary Report
class Order_Summary_Report {
//the use of $this with redirection arrow -> it will display the header information first.
   public function Display__Message($mess) {
      $this->Display_HTML_Header();
      echo <<<RETFORM
        <center> $mess
        <form method="post">
        <INPUT TYPE='SUBMIT' NAME='Return' VALUE='Main Menu'>
         </form>
         </center>
RETFORM;
//This will display the HTML_Footer information last.
       $this->Display_HTML_Footer();
   } 
//This function will display the Order Report in the order of HTML Header then the Data Entry Form and finally the HTML Footer.
   public function Display_Order_Report() {
       $this->Display_HTML_Header();
       $this->Display_Entry_form();
       $this->Display_HTML_Footer();
    } 
//This function defines what is in the HTML Heaader section.
   public function Display_HTML_Header() {
     $header =<<<ENDFORM
     <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
     <html>
     <head>
     <title>PHP HereString </title>
     </head>
     <body>
ENDFORM;
  echo $header;
}
//This function defines the HTML Footer information to be displayed.
public function Display_HTML_Footer() {
  $Footer =<<<ENDFORM
    </body>
     </html>
ENDFORM;
  echo $Footer;
}
//This function defines the Report Header information to be displayed.
public function Display_Report_Header() {
  $rptDate = date("m", time())."/".date("d",time())."/".date("y",time()); 
 echo <<<ENDREORTHEAD
  <body bgcolor="DDFFEE">
  <h2>Date: $rptDate </h2>
  <h1><center>WEB 255 Lab 3 OOP Order Entry </center></h1>
   <h1><center>Order Report</center></h1>
ENDREORTHEAD;
}
//This function defines the  Summary Report information to be displayed and in what order.
public function Display_Summary_Report($rows) {
  $this-> Display_HTML_Header();  
  $this->Display_Report_Header();
  $pos = 0;
  foreach($rows as $key => $value){
    echo '<b>Name: </b>'.$rows[$pos]['Fname']." ".$rows[$pos]['Lname'];
    echo "<br>";
    echo '<b>Account: </b>'.$rows[$pos]['Account'];
    echo "<br>";
    echo '<b>CCN: </b>'.$rows[$pos]['CCN']."<b>   ExpDate: </b>".$rows[$pos]['ExpDate'];
    echo "<br>";
    echo '<b>Item: </b>'.$rows[$pos]['Item']."<b>   Qantity: </b>".$rows[$pos]['Qty'];
    echo "<br> <hr> <br>";
    $pos++;
 } 
   echo <<<RETFORM
      <center>
      <form method="post" action="dispatcher.php">
      <INPUT TYPE='SUBMIT' NAME='Return' VALUE='Main Menu'>
      </form>
      </center>
RETFORM;
    $this-> Display_HTML_Footer(); 
}
}// end Order View Class 

?>