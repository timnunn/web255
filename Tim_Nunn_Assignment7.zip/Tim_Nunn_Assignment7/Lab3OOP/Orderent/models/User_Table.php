<?PHP
//Provides a layer between the database and application
namespace Orderent\Models;
//displays properties of this class.  Not visible to outside because they are set to private.
class User_Table {
   private $User = 'root';
   private $db_name = 'lab3';
   private $Servername = 'localhost';
   private $Password = '';
   private $Port = 3306;
   private static $Conn;
   //Establishes connection to the database  
   public function __construct() {
      $User = 'root';
      $db_name = 'lab3';
      $Servername = 'localhost';
      $Password = '';
      if (!function_exists('mysqli_init') && !extension_loaded('mysqli')) {
          echo 'We don\'t have mysqli!!!';
      } else {
         // echo 'Phew we have it!';
      }
      self::$Conn = mysqli_connect($Servername, 
                             $User, 
                             $Password, 
                             $db_name);
      // Check connection
      if (Self::$Conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
      } 
    }
// function to close the connection to the database.
    public function Close(){
      mysqli_close($Conn);
    }
//Function to validate user data submitted
    public function Validate_User_Data() {
       $Data_Valid = true; 
       if (!isset($_REQUEST["FName"]))   $Data_Valid = false; 
       if (!isset($_REQUEST["LName"]))   $Data_Valid = false; 
       if (!isset($_REQUEST["ID"]))     $Data_Valid = false; 
       if (!isset($_REQUEST["PassWD"])) $Data_Valid = false; 
       return $Data_Valid;
    }    

// Database Routines
/Function to add user data to the Users table
   public function Insert_Request_Data(){
      $sql_statement = "insert into Users (Fname,Lname,ID,PassWD) values ('"
        .$_REQUEST["FName"]
        ."', '"
        .$_REQUEST["LName"]
        ."', '"
        .$_REQUEST["ID"]
        ."', '"
        .$_REQUEST["PassWD"]
        ."') ";
      self::$Conn->query($sql_statement)
          or die("query failed: $query ".mysql_error());
      return true;
   }
//Fetches data from the Users table.
   public function Get_User_Data(){
       $sql_statement = 'select * from users';
       self::$Conn->query("SET NAMES utf8"); 
       $result = self::$Conn->query($sql_statement);
       while ($row = mysqli_fetch_array($result)) {
          $result_array[] = $row; 
       }
       mysqli_free_result($result);
       return $result_array;	
   }

// Utility Methods
   public function GetType(){
     return "User_Table";
   }
}// end Order class
?>