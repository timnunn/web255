drop database if exists Lab3;
create database Lab3;
use Lab3;
drop table if exists Orders;
create table Orders(
    ID          MEDIUMINT NOT NULL AUTO_INCREMENT,
	Fname	    varchar(25),
	Lname	    varchar(35),
	Account 	varchar(10),
	CCN		    varchar(16),
    ExpDate     Date,
	Item    	text null,
    Qty         Int,
	PRIMARY KEY (ID));
grant delete, insert, select, update on Orders to joeuser@localhost identified by 'resueoj';
drop table if exists Users;
create table Users(
	Fname	        varchar(25),
	Lname	        varchar(35),
	ID       	varchar(8) NOT NULL,
	PassWD		varchar(8),
	PRIMARY KEY (ID));
grant delete, insert, select, update on Users to joeuser@localhost identified by 'resueoj';
FLUSH PRIVILEGES;
insert into Users (Fname,Lname,ID,PassWD) values('Eric','Yoxheimer','appeyox','appeyox');
insert into Users (Fname,Lname,ID,PassWD) values('Admin','Admin','admin','admin');
COMMIT;
